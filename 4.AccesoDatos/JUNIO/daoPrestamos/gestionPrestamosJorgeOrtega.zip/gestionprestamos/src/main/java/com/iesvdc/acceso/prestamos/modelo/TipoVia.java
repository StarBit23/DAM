package com.iesvdc.acceso.prestamos.modelo;

public enum TipoVia {
    CALLE, CAMINO, AVENIDA, CARRERA, PASEO
}
