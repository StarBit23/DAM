package com.iesvdc.acceso.prestamos;

import com.iesvdc.acceso.prestamos.conexion.Conexion;

public class ConexOracle {
    public static void main(String[] args) {
        Conexion connection = new Conexion();
    }
}