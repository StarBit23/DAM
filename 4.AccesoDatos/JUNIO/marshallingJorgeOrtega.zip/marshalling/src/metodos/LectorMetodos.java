public class LectorMetodos {
    
}
