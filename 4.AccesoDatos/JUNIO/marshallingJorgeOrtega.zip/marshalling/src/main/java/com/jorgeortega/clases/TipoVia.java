package com.jorgeortega.clases;

public enum TipoVia {
    CALLE, CAMINO, AVENIDA, CARRERA, PASEO
}
